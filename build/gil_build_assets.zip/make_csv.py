import csv, io, sys
sys.path.insert(0, '.')
from data import P, STOPS, DAYS, place_url, RESTAURANTS, AREAS, rest_url, RATED
rows=[["일차","날짜","순서","시각","구분","이름","현지 이름","위도","경도","메모","구글지도"]]
for d,o,t,k,cat,memo in STOPS:
    ko,jp,lat,lng,pid=P[k]
    rows.append([f"{d}일차",DAYS[d][0],o,t,cat,ko,jp,lat,lng,memo,place_url(k)])
for r in RESTAURANTS:
    rows.append(["식당","","","","식당(Claude 추가)" if r[0] in RATED else "식당(재원)",r[0],r[1],r[2],r[3]," · ".join(x for x in (" / ".join(AREAS[a] for a in r[5]),r[6],r[7],(f"구글 ★{RATED[r[0]][0]} ({RATED[r[0]][1]:,})" if r[0] in RATED else "")) if x),rest_url(r)])
buf=io.StringIO(); csv.writer(buf).writerows(rows)
open('places.csv','w',encoding='utf-8').write(buf.getvalue())
print(len(rows)-1,"rows")
