# -*- coding: utf-8 -*-
# 후쿠오카 가족여행 길잡이 (휴대폰용) 생성기 — data.py → guide.html
# 같은 파일을 아티팩트로 게시하고, 오프라인용으로도 그대로 쓴다.
import html, json, math
import base64, io, os
from PIL import Image
from urllib.parse import quote
import os as _os
APP = bool(_os.environ.get("APP"))
from data import (P, STOPS, LEGS, DAYS, MEALS, AREAS, RESTAURANTS, SIM_NOTES, TAXI, CRITICAL, RESV, RESV_APP, PACK, RATED,
                  place_url, dir_url, rest_url, rest_ok, fits_kind, day_chain, _m)

E = html.escape
MODE = {"transit": "대중교통", "walking": "도보", "driving": "택시·차"}
STATUS = {"ok": ("확인", "ok"), "est": ("추정", "est"), "chk": ("현지 확인", "chk")}
TAXI_KEYS = {t[0] for t in TAXI}
UPDATED = "2026-10-30"
DAYLIST = {1: "https://maps.app.goo.gl/jMJswz5zMSD1g49E8", 2: "https://maps.app.goo.gl/YLVokDyjfDRXp15x6", 3: "https://maps.app.goo.gl/ac8JMoYrJKBqTr6x5",
           4: "https://maps.app.goo.gl/KasUZuSEZ1xdQYZo6", 5: "https://maps.app.goo.gl/qp2zxsGyehpnB4iV9", 6: "https://maps.app.goo.gl/tH7cH8kDu2r2MWDg9"}
# 날짜별 내 지도 (2026-10-30, 그날 동선만 보임)
MYMAPS_DAY = {1: "1mtnKfyyQ8K9Q8oH5T6s12i5PsJPjU0s", 2: "1VT3QItw2GKPFtoFlTGlwWcyRFD3XGCc", 3: "1TNs9g6nrR_yUUP9xeNHe4BA89TPHKnk",
              4: "1appWsh9IyiYFzEgV3uq_F--upS26Z8Y", 5: "1rmIsvzI3sJOuzapxMpaqnFJoBPL7Le4", 6: "1odHLJcui68Y6g5xbLhD7h11rr4WisKY"}

# 관광지 소개(가족용) — 2026-10-30 조사, research/placeinfo_*.json → placeinfo.json
INFO = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "placeinfo.json"), encoding="utf-8"))
PHOTO_META = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "photos", "meta.json"), encoding="utf-8"))
def photos():
    out = {}
    for k, (title, lic, artist, url) in PHOTO_META.items():
        f = os.path.join(os.path.dirname(os.path.abspath(__file__)), "photos", ("cruise" if k == "naka" else k) + ".jpg")
        if not os.path.exists(f) or k not in INFO: continue
        out[k] = {"src": "data:image/jpeg;base64," + base64.b64encode(open(f, "rb").read()).decode(), "cap": f"사진: {artist} · {lic} · 위키미디어 공용", "url": url}
    return out
def info_btn(k):
    return (f'<button class="info" type="button" data-info="{k}" aria-label="{E(short(k))} 소개 보기">'
            '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>소개</button>') if k in INFO else ""

# 지역별 구글지도 저장 목록(링크 공유, 2026-10-30 만듦 — 링크 있는 사람은 누구나 보기 가능, 재원 계정 이름·사진 표시) — 식사 [전체 식당 지도] 버튼과 식당 탭 [지도로 보기]
LISTS = {
    "tenjin": ("후쿠오카 식당·덴진", "https://maps.app.goo.gl/NhwaAujRUsCvHWwD6"),
    "ohori": ("후쿠오카 식당·오호리", "https://maps.app.goo.gl/W9Ea6xGiaggWQawC6"),
    "nakasu": ("후쿠오카 식당·나카스·하카타", "https://maps.app.goo.gl/BuExoUQA6iAEgoRo8"),
    "yufuin": ("유후인 식당", "https://maps.app.goo.gl/QFq4sdUZZxE4kwuC6"),
    "kannawa": ("벳푸 간나와 식당", "https://maps.app.goo.gl/FHG6yAgpKnAEHq8M8"),
    "momochi": ("후쿠오카 식당·모모치", "https://maps.app.goo.gl/Fj51NZUnyY9axSzX9"),
    "marine": ("마린월드 식당", "https://maps.app.goo.gl/nkh4o5A4DaKvUcdS6"),
    "airport": ("후쿠오카공항 식당", "https://maps.app.goo.gl/5apqMpTNpm6m6qkK6"),
}
AREA_LIST = {"hotel": "tenjin", "tenjin": "tenjin", "ohori": "ohori", "kawabata": "nakasu", "canal": "nakasu", "hakata": "nakasu",
             "yufuin": "yufuin", "kannawa": "kannawa", "momochi": "momochi", "marine": "marine", "airport": "airport"}
def list_btn(area, label=None, cls="btn ghost sm", show_name=True):
    lk = AREA_LIST.get(area)
    if not lk or not LISTS[lk][1]: return ""
    nm, url = LISTS[lk]
    return (f'<a class="{cls}" href="{E(url)}" target="_blank" rel="noopener" title="구글지도 저장 목록 「{E(nm)}」">'
            f'{E(label or "전체 식당 지도")}{" · " + E(nm) if show_name else ""}</a>')

def rate_tag(r):
    if r[0] in RATED:
        v, c = RATED[r[0]]
        return f'<span class="rt ai">Claude 추가 · 구글 ★{v} ({c:,})</span>'
    return '<span class="rt mine">재원 저장</span>'

def near_dir(r):
    return ("https://www.google.com/maps/dir/?api=1"
            f"&destination={quote(r[1])}&destination_place_id={r[4]}&travelmode=walking")

def short(k):
    n = P[k][0]
    return n.split(" (")[0]

# ---------- 하루 동선 구성 ----------
def day_items(d):
    seq, legs = day_chain(d)
    stops = [s for s in STOPS if s[0] == d]
    ptr = 0
    items = []
    for i, k in enumerate(seq):
        st = None
        if ptr < len(stops) and stops[ptr][3] == k:
            st = stops[ptr]; ptr += 1
        items.append({"kind": "place", "key": k, "t": st[2] if st else "", "cat": st[4] if st else "",
                      "note": st[5] if st else "", "no": i + 1})
        if i < len(legs):
            items.append({"kind": "move", "leg": legs[i], "t": legs[i][4]})
    # 시각 보정(없으면 앞 항목 시각) 후 끼니 끼워 넣기
    last = "00:00"
    for it in items:
        it["sort"] = it["t"] or last
        last = it["sort"]
    for m in [m for m in MEALS if m[0] == d]:
        pos = len(items)
        for i, it in enumerate(items):
            if it["t"] and _m(it["t"]) > _m(m[1]):
                pos = i; break
        items.insert(pos, {"kind": "meal", "meal": m, "t": m[1], "sort": m[1]})
    assert ptr == len(stops), f"{d}일차 STOPS 순서가 동선과 안 맞음: {stops[ptr:]}"
    return seq, items

# ---------- 동선 지도 (SVG, 지역별로 나눔) ----------
def dist_km(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (P[a][2], P[a][3], P[b][2], P[b][3]))
    h = math.sin((la2-la1)/2)**2 + math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 6371 * 2 * math.asin(math.sqrt(h))

def _groups(keys, th):
    parent = {k: k for k in keys}
    def f(x):
        while parent[x] != x: x = parent[x]
        return x
    for a in keys:
        for b in keys:
            if a < b and dist_km(a, b) <= th:
                parent[f(a)] = f(b)
    g = {}
    for k in keys: g.setdefault(f(k), []).append(k)
    return list(g.values())

def _overlap(keys):
    if len(keys) < 2: return False
    pos = _project(keys)
    ks = list(keys)
    for i in range(len(ks)):
        for j in range(i+1, len(ks)):
            (x1, y1), (x2, y2) = pos[ks[i]], pos[ks[j]]
            if abs(x1-x2) < 26 and abs(y1-y2) < 26: return True
    return False

def _split(keys, th):
    out = []
    for g in _groups(keys, th):
        if _overlap(g) and th > 0.7:
            out += _split(g, th / 2)
        else:
            out.append(g)
    return out

def clusters(seq, th=10):
    keys = list(dict.fromkeys(seq))
    groups = _split(keys, th)
    gid = {k: n for n, g in enumerate(groups) for k in g}
    out = []
    for i, k in enumerate(seq):
        if out and gid[seq[out[-1]["idx"][-1]]] == gid[k]:
            out[-1]["idx"].append(i); out[-1]["keys"].add(k)
        else:
            out.append({"keys": {k}, "idx": [i]})
    return out

W, H, PAD = 340, 230, 30
def _project(keys):
    keys = sorted(keys)
    lats = [P[k][2] for k in keys]; lngs = [P[k][3] for k in keys]
    lat0 = sum(lats) / len(lats); c = math.cos(math.radians(lat0))
    xs = [lo * c for lo in lngs]; ys = lats
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    span = max(maxx - minx, maxy - miny, 0.006)
    sc = min((W - 2*PAD) / max(maxx - minx, span*0.35), (H - 2*PAD) / max(maxy - miny, span*0.35))
    cx, cy = (minx + maxx) / 2, (miny + maxy) / 2
    return {k: (W/2 + (P[k][3]*c - cx) * sc, H/2 - (P[k][2] - cy) * sc) for k in keys}

REGION = [((33.2, 33.32, 131.3, 131.4), "유후인"), ((33.305, 33.325, 131.46, 131.485), "벳푸 간나와"), ((33.25, 33.35, 131.43, 131.55), "벳푸"),
          ((33.5, 33.8, 130.3, 130.5), "후쿠오카")]
def region(k):
    la, lo = P[k][2], P[k][3]
    for (a, b, c, e), n in REGION:
        if a <= la <= b and c <= lo <= e: return n
    return ""


def dist_m(a, b):
    (lo1, la1), (lo2, la2) = a, b
    p1, p2 = math.radians(la1), math.radians(la2)
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lo2 - lo1) / 2) ** 2
    return 6371000 * 2 * math.asin(math.sqrt(h))

# ---------- 하루 동선 지도: 구글 내 지도(날짜별) 화면 캡처 + 번호 ----------
# 캡처 조건(2026-10-30): https://www.google.com/maps/d/embed?mid=<mid>&ll=<lat>,<lng>&z=<z>&hl=ko 를
# 브라우저 CSS 1133x1231로 열고 13초 기다린 뒤 800x869 스크린샷 → daymaps/<키>.jpg. 지도 중심 = 화면 중심.
HERE = os.path.dirname(os.path.abspath(__file__))
DMP = json.load(open(os.path.join(HERE, "daymap_params.json"), encoding="utf-8"))
SHOT_W, SHOT_H, CSS_W = 800, 869, 1133
INSETS = {3: [("3y", "유후인 확대")], 4: [("4y", "유후인 확대"), ("4k", "간나와 지옥 확대")]}
DISP_W = 330          # 휴대폰에서 지도 폭(대략, css px) — 번호가 겹치는지 판단용

def _wpx(lon, lat, z):
    n = 2 ** z * 256
    s = math.sin(math.radians(lat))
    return (lon + 180) / 360 * n, (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n

def _shot_xy(p, k):
    sc = SHOT_W / CSS_W
    cx, cy = _wpx(p["lon"], p["lat"], p["z"])
    x, y = _wpx(P[k][3], P[k][2], p["z"])
    return SHOT_W / 2 + (x - cx) * sc, SHOT_H / 2 + (y - cy) * sc

def _ranges(nums):
    nums = sorted(set(nums)); out = []; i = 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1: j += 1
        out.append(str(nums[i]) if j == i else (f"{nums[i]}·{nums[j]}" if j == i + 1 else f"{nums[i]}~{nums[j]}"))
        i = j + 1
    return "·".join(out)

def shot_map(name, seq, keys=None, cap="", href=""):
    """캡처 이미지를 핀 범위로 잘라 data URI + 번호 배지(HTML)로 돌려준다"""
    p = DMP[name]
    f = os.path.join(HERE, "daymaps", f"day{name}.jpg" if name.isdigit() else f"{name}.jpg")
    if not os.path.exists(f): return ""
    keys = keys or list(dict.fromkeys(seq))
    pts = {k: _shot_xy(p, k) for k in keys}
    xs = [v[0] for v in pts.values()]; ys = [v[1] for v in pts.values()]
    pad = 46
    x0, x1 = min(xs) - pad, max(xs) + pad
    y0, y1 = min(ys) - pad - 22, max(ys) + pad          # 핀 머리가 위로 솟으니 위쪽 여유
    # 너무 작거나 가늘지 않게
    w = max(x1 - x0, 380); cxm = (x0 + x1) / 2; x0, x1 = cxm - w / 2, cxm + w / 2
    h = max(y1 - y0, w * 0.62)
    if h > w * 1.25:                                    # 세로로 긴 동선은 옆을 넓혀 비율 맞추기
        w = h / 1.25; x0, x1 = cxm - w / 2, cxm + w / 2
    cym = (y0 + y1) / 2; y0, y1 = cym - h / 2, cym + h / 2
    top, bot = 44, SHOT_H - 26                          # 위 제목줄·아래 확대 버튼 빼기
    if x0 < 0: x1 -= x0; x0 = 0
    if x1 > SHOT_W: x0 -= x1 - SHOT_W; x1 = SHOT_W
    if y0 < top: y1 += top - y0; y0 = top
    if y1 > bot: y0 -= y1 - bot; y1 = bot
    x0, y0 = max(x0, 0), max(y0, top)
    box = tuple(int(round(v)) for v in (x0, y0, x1, y1))
    im = Image.open(f).convert("RGB").crop(box)
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=66, optimize=True)
    uri = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    cw, chh = box[2] - box[0], box[3] - box[1]
    # 배지 위치(핀 머리) 및 겹침 합치기
    nums = {}
    for i, k in enumerate(seq):
        if k in pts: nums.setdefault(k, []).append(i + 1)
    th = 25 * cw / DISP_W
    groups = []
    for k, ns in nums.items():
        x, y = pts[k][0] - box[0], pts[k][1] - box[1] - 19
        for g in groups:
            if any(abs(x - gx) < th and abs(y - gy) < th * 0.8 for gx, gy in g["xy"]):
                g["xy"].append((x, y)); g["n"] += ns; break
        else:
            groups.append({"xy": [(x, y)], "n": list(ns)})
    badges = []
    k2 = cw / DISP_W                                     # css px → 이미지 px
    placed = []
    for g in groups:
        x = sum(v[0] for v in g["xy"]) / len(g["xy"]); y = sum(v[1] for v in g["xy"]) / len(g["xy"])
        lab = _ranges(g["n"]); bw = (12 + 7.5 * len(lab)) * k2
        for _ in range(4):                               # 다른 배지와 겹치면 아래로 비켜 놓기
            hit = [q for q in placed if abs(q[0] - x) < (q[2] + bw) / 2 + 2 * k2 and abs(q[1] - y) < 26 * k2]
            if not hit: break
            y = max(q[1] for q in hit) + 27 * k2
        placed.append((x, y, bw))
        badges.append(f'<span class="bdg" style="left:{100 * x / cw:.1f}%;top:{100 * y / chh:.1f}%">{lab}</span>')
    capt = f'<div class="mapcap">{E(cap)}</div>' if cap else ""
    return (f'{capt}<a class="shot" href="{E(href)}" target="_blank" rel="noopener" aria-label="{E(cap or "동선 지도")} — 구글 내 지도로 크게 보기">'
            f'<img src="{uri}" width="{cw}" height="{chh}" alt="">{"".join(badges)}'
            f'<span class="gattr">지도 © Google</span></a>')
def near_txt(r, anchor):
    if not anchor: return ""
    m = dist_m((P[anchor][3], P[anchor][2]), (r[3], r[2]))
    walk = round(m * 1.3 / 75)
    dist = f"{m/1000:.1f}km" if m >= 1000 else f"{int(round(m, -1))}m"
    return f"{short(anchor)}에서 직선 {dist} (걸어서 약 {max(walk,1)}분, 추정)"

def overview_links(seq, legs):
    out = []
    for cl in clusters(seq):
        pts = []
        for i in cl["idx"]:
            if not pts or pts[-1] != seq[i]: pts.append(seq[i])
        if len(pts) < 2: continue
        modes = {legs[i][3] for i in cl["idx"] if i < len(legs) and (i + 1) in cl["idx"]}
        mode = "walking" if modes <= {"walking"} else "driving"
        chunks, start = [], 0
        while start < len(pts) - 1:
            chunks.append(pts[start:start + 5]); start += 4
        reg = region(pts[0]) or "이동"
        for n, ch in enumerate(chunks, 1):
            o, de, wp = ch[0], ch[-1], ch[1:-1]
            url = ("https://www.google.com/maps/dir/?api=1"
                   f"&origin={quote(P[o][1])}&origin_place_id={P[o][4]}"
                   f"&destination={quote(P[de][1])}&destination_place_id={P[de][4]}"
                   + (f"&waypoints={quote('|'.join(P[w][1] for w in wp))}&waypoint_place_ids={'|'.join(P[w][4] for w in wp)}" if wp else "")
                   + f"&travelmode={mode}")
            out.append(f'<a class="btn ghost sm" href="{E(url)}" target="_blank" rel="noopener">{E(reg)} 동선{f" {n}/{len(chunks)}" if len(chunks) > 1 else ""}</a>')
    return "".join(out)

def day_map(d, seq, legs):
    href = f"https://www.google.com/maps/d/viewer?mid={MYMAPS_DAY[d]}"
    main = shot_map(str(d), seq, href=href)
    ins = "".join(shot_map(n, seq, DMP[n]["keys"], cap, href) for n, cap in INSETS.get(d, []))
    names = []
    for i, k in enumerate(seq):
        names.append(f'<li><b>{i+1}</b> {E(short(k))}</li>')
    return ('<details class="daymap" open><summary>하루 동선 지도 <span class="sub">번호 = 이동 순서 · 지도를 누르면 구글 내 지도</span></summary>'
            + main + ins + f'<ol class="maplist">{"".join(names)}</ol>'
            + f'<a class="btn go" href="{href}" target="_blank" rel="noopener">구글 내 지도에서 {d}일차 동선 보기</a>'
            + f'<a class="btn ghost sm" href="{DAYLIST[d]}" target="_blank" rel="noopener">구글지도 저장 목록 「{d}일차」 (메모에 순번·시각)</a>'
            + '<p class="fine">구글 내 지도는 재원·아내 구글 계정으로 열려요. 저장 목록은 링크로 누구나 보기. 지도 화면은 2026-10-30 캡처.</p></details>')

# ---------- 카드 ----------
DEST_CATS = {"관광", "쇼핑", "선택"}
def done_btn(key):
    return f'<button class="dn" type="button" data-done="{E(key)}" aria-pressed="false" aria-label="완료 표시"><span class="dn-box"></span><span class="dn-t">완료</span></button>'

def crit_for(d, t):
    return [c for c in CRITICAL if c[0] == d and c[1] == t]

def place_html(d, it):
    k = it["key"]
    ko, jp = P[k][0], P[k][1]
    crit = "".join(f'<div class="crit">⏰ {E(c[1])} {E(c[2])}</div>' for c in crit_for(d, it["t"]))
    taxi = (f'<button class="btn ghost sm" data-taxi="{k}" type="button">택시 카드</button>' if k in TAXI_KEYS else "")
    note = f'<p class="note">{E(it["note"])}</p>' if it["note"] else ""
    cat = f'<span class="cat">{E(it["cat"])}</span>' if it["cat"] else ""
    dk = f'{d}|p|{it["sort"]}|{k}'
    dest = " dest" if it["cat"] in DEST_CATS else ""
    return (f'<li class="it place{dest}" data-t="{it["sort"]}" data-k="{E(dk)}"><div class="tm">{E(it["t"]) or "&nbsp;"}</div>'
            f'<div class="body">{done_btn(dk)}<div class="pname"><span class="no">{it["no"]}</span>{E(ko)} {cat}{info_btn(k)}</div>'
            f'<div class="jp" lang="ja">{E(jp)}</div>{crit}{note}'
            f'<div class="acts"><a class="btn ghost sm" href="{E(place_url(k))}" target="_blank" rel="noopener">지도</a>{taxi}</div></div></li>')

def move_html(d, it):
    l = it["leg"]
    _, a, b, mode, t, desc, stop, tm, stt = l
    lab, cls = STATUS[stt]
    crit = "".join(f'<div class="crit">⏰ {E(c[1])} {E(c[2])}</div>' for c in crit_for(d, t))
    hint = (f'<div class="hint">앱에서 <b>출발 시간 → {E(t)}</b>으로 바꾸면 그 시각 열차·버스가 나와요</div>'
            if mode == "transit" and t else "")
    stopl = f'<div class="kv"><span>타는 곳</span><span>{E(stop)}</span></div>' if stop else ""
    dk = f'{d}|m|{it["sort"]}|{a}>{b}'
    return (f'<li class="it move m-{mode}" data-t="{it["sort"]}" data-k="{E(dk)}"><div class="tm">{E(t)}</div><div class="body">{done_btn(dk)}'
            f'<div class="mhead"><span class="mode">{MODE[mode]}</span><span class="st st-{cls}">{lab}</span></div>'
            f'<div class="mdesc">{E(desc)}</div>{stopl}'
            f'<div class="kv"><span>시간</span><span>{E(tm)}</span></div>{crit}{hint}'
            f'<a class="btn {"go" if mode != "walking" else "walk"}" href="{E(dir_url(a, b, mode))}" target="_blank" rel="noopener">길찾기 · {E(short(b))}</a>'
            f'</div></li>')

def rest_slots(r):
    return [m for m in MEALS if m[3] in r[5] and rest_ok(r, m[0], m[1]) and fits_kind(r, m[2])]

def meal_recs(d, m, anchor):
    dur = 20 if m[2] == "아침거리 사기" else 60
    recs = [r for r in RESTAURANTS if m[3] in r[5] and rest_ok(r, d, m[1], dur) and fits_kind(r, m[2])]
    if anchor:
        recs.sort(key=lambda r: dist_m((P[anchor][3], P[anchor][2]), (r[3], r[2])))
    return recs

PREP_EAT = "아침(사 둔 것)"
def meal_html(d, it):
    m = it["meal"]
    if m[2] == PREP_EAT:
        dk = f'{d}|e|{m[1]}|{m[2]}'
        return (f'<li class="it meal prep" data-t="{it["sort"]}" data-k="{E(dk)}"><div class="tm">{E(m[1])}</div><div class="body">{done_btn(dk)}'
                f'<div class="mealh">{E(m[2])}</div><p class="note">{E(m[4])}</p></div></li>')
    anchor = it.get("anchor")
    recs = meal_recs(d, m, anchor)
    rl = "".join(f'<li><span class="no rno">{n}</span><div><a href="{E(rest_url(r))}" target="_blank" rel="noopener"><b>{E(r[0])}</b></a>{rate_tag(r)}'
                 f'<span class="rd">{E(near_txt(r, anchor))}</span>'
                 f'<span class="rh">{E(r[7])}</span><span class="rm">{E(r[6])}</span></div></li>' for n, r in enumerate(recs, 1))
    acts = ""
    if recs:
        acts = (f'<div class="macts">{list_btn(m[3], "전체 식당 지도 (구글맵)", "btn ghost sm", False)}'
                f'<a class="btn ghost sm" href="{E(near_dir(recs[0]))}" target="_blank" rel="noopener">가장 가까운 곳 길찾기 · {E(recs[0][0].split(" (")[0])}</a></div>')
    hint = f'<p class="fine">거리 = {E(short(anchor))}(직전 장소)에서 직선거리 · 가까운 순 · 길찾기는 지금 내 위치에서 출발</p>' if anchor and recs else ""
    body = (f'{acts}<details><summary>추천 {len(recs)}곳 목록</summary>{hint}<ul class="recs">{rl}</ul></details>' if recs
            else '<p class="note">저장한 식당 중 이 시간·지역에 맞는 곳이 없어요</p>')
    note = f' · {E(m[4])}' if m[4] else ""
    dk = f'{d}|e|{m[1]}|{m[2]}'
    cur = AREA_LIST.get(m[3])
    alt = "".join(f'<a class="chip" href="{E(u)}" target="_blank" rel="noopener">{E(n)}</a>' for k2, (n, u) in LISTS.items() if u and k2 != cur)
    alt = f'<details class="alt"><summary>다른 지역에서 먹게 되면</summary><div class="altl">{alt}</div><p class="fine">구글지도 저장 목록이 열려요 — 지도에서 지금 내 위치와 가까운 곳을 고르면 돼요.</p></details>'
    pcls = " prep" if m[2] == "아침거리 사기" else ""
    return (f'<li class="it meal{pcls}" data-t="{it["sort"]}" data-k="{E(dk)}"><div class="tm">{E(m[1])}</div><div class="body">{done_btn(dk)}'
            f'<div class="mealh">{E(m[2])} <span class="sub">{E(AREAS[m[3]])}{note}</span></div>{body}{alt}</div></li>')

def day_html(d):
    seq, items = day_items(d)
    legs = [l for l in LEGS if l[0] == d]
    date, dow, title = DAYS[d]
    crits = [c for c in CRITICAL if c[0] == d]
    crit_box = ("<div class=\"critbox\"><b>오늘 놓치면 안 되는 시각</b><ul>" +
                "".join(f'<li><span class="ct">{E(c[1])}</span> {E(c[2])}' + (f' <span class="miss">놓치면: {E(c[3])}</span>' if c[3] else "") + '</li>' for c in crits)
                + "</ul></div>") if crits else ""
    rows = []
    last = None
    for it in items:
        if it["kind"] == "place": last = it["key"]
        elif it["kind"] == "meal": it["anchor"] = last or (seq[0] if seq else None)
        rows.append(place_html(d, it) if it["kind"] == "place" else move_html(d, it) if it["kind"] == "move" else meal_html(d, it))
    notes = "".join(f"<li>{E(n)}</li>" for n in SIM_NOTES.get(d, []))
    notes_html = f'<details class="notes"><summary>알아둘 것 {len(SIM_NOTES.get(d, []))}</summary><ul>{notes}</ul></details>' if notes else ""
    return (f'<section class="day" id="day-{d}" data-day="{d}" hidden>'
            f'<header class="dayhead"><div class="dd">{d}일차 · {E(date)} ({E(dow)})</div><h2>{E(title)}</h2></header>'
            f'{crit_box}{day_map(d, seq, legs)}<ol class="tl">{"".join(rows)}</ol>{notes_html}</section>')

# ---------- 식당 탭 ----------
AREA_ORDER = ["hotel", "tenjin", "ohori", "kawabata", "canal", "hakata", "momochi", "yufuin", "kannawa", "beppu_st", "marine", "airport"]
def food_html():
    chips = ['<button class="chip on" data-area="all" type="button">전체</button>']
    blocks = []
    for ak in AREA_ORDER:
        rs = [r for r in RESTAURANTS if r[5][0] == ak]
        if not rs: continue
        chips.append(f'<button class="chip" data-area="{ak}" type="button">{E(AREAS[ak].split(" (")[0])}</button>')
        cards = []
        for n, r in enumerate(rs, 1):
            sl = rest_slots(r)
            slt = ", ".join(f"{DAYS[m[0]][0]} {m[2]}" for m in sl) or "맞는 끼니 없음"
            cards.append(f'<li class="rest"><div class="rn"><span class="no rno">{n}</span><a href="{E(rest_url(r))}" target="_blank" rel="noopener">{E(r[0])}</a>{rate_tag(r)}</div>'
                         f'<div class="jp" lang="ja">{E(r[1])}</div><div class="rh">{E(r[7])}</div>'
                         f'<div class="rm">{E(r[6])}</div><div class="rs">추천 끼니: {E(slt)}</div></li>')
        mpb = list_btn(ak, "구글지도로 보기", "btn walk")
        blocks.append(f'<div class="area" data-area="{ak}"><h3>{E(AREAS[ak])} <span class="sub">{len(rs)}곳</span></h3>{mpb}<ul class="restlist">{"".join(cards)}</ul></div>')
    return (f'<section id="food" class="tab" hidden><h2 class="th">저장한 식당·카페 <span class="sub">{len(RESTAURANTS)}곳 · 영업시간은 구글지도 기준</span></h2>'
            f'<div class="chips">{"".join(chips)}</div>{"".join(blocks)}</section>')

# ---------- 택시 탭 ----------
def taxi_html():
    cards = []
    for k, jp, addr, tel in TAXI:
        cards.append(f'<li><button class="taxirow" data-taxi="{k}" type="button"><span class="tko">{E(short(k))}</span>'
                     f'<span class="tjp" lang="ja">{E(jp)}</span></button></li>')
    data = {k: {"ko": short(k), "jp": jp, "addr": addr, "tel": tel} for k, jp, addr, tel in TAXI}
    return (f'<section id="taxi" class="tab" hidden><h2 class="th">택시 카드 <span class="sub">누르면 기사님께 보여줄 큰 화면이 열려요</span></h2>'
            f'<ul class="taxilist">{"".join(cards)}</ul>'
            f'<p class="fine">전화번호는 기사님 내비 검색에 쓸 수 있어요. 일본 택시 문은 자동으로 열리고 닫혀요.</p></section>', data)

# ---------- 예약 탭 ----------
def book_html():
    rows = "".join(f'<li class="bk"><div class="bd">{E(a)}</div><div class="bb"><div class="bt">{E(b)}</div>'
                   f'<div class="bm">{E(c)}</div><div class="bx">{E(e)}</div></div></li>' for a, b, c, e in (RESV_APP if APP else RESV))
    crit = "".join(f'<li><span class="ct">{DAYS[c[0]][0]} {E(c[1])}</span> {E(c[2])}</li>' for c in CRITICAL)
    return (f'<section id="book" class="tab" hidden><h2 class="th">예약·QR</h2><ul class="bklist">{rows}</ul>'
            '<div class="card"><h3>JR QR 승차</h3><ul class="plain"><li>JR 예약 메일의 QR티켓 링크(1~4)를 휴대폰에서 열어 한 사람씩 개찰구에 대기 — 앱 로그인 불필요</li>'
            '<li>스크린샷·인쇄 QR은 안 돼요 → 일본 데이터 필요</li><li>유후인노모리 65011 · 소닉 69616</li></ul></div>'
            f'<div class="card"><h3>놓치면 안 되는 시각 (전체)</h3><ul class="plain crits">{crit}</ul></div>'
            '<div class="card"><h3>연락처</h3><ul class="plain sel">'
            '<li>BASE LAYER <span class="mono">092-406-1256</span></li><li>시키사이 <span class="mono">0977-85-8566</span></li>'
            '<li>경찰 <span class="mono">110</span> · 구급·화재 <span class="mono">119</span></li>'
            '<li>영사콜센터(24시간) <span class="mono">+82-2-3210-0404</span></li></ul></div>'
            '</section>')

# ---------- 준비물 탭 ----------
def pack_html():
    secs = []
    n = 0
    for cat, items in PACK:
        lis = []
        for name, add in items:
            n += 1
            lis.append(f'<li><label class="pk"><input type="checkbox" data-pk="{E(name)}"><span>{E(name)}</span>'
                       + ('<em class="add">추가</em>' if add else "") + '</label></li>')
        secs.append(f'<div class="pcat"><h3>{E(cat)} <span class="sub pcnt" data-cat="{E(cat)}"></span></h3><ul class="plist">{"".join(lis)}</ul></div>')
    return (f'<section id="pack" class="tab" hidden><h2 class="th">준비물 <span class="sub" id="packCnt"></span></h2>'
            '<p class="fine" style="margin-top:0">체크는 이 휴대폰에만 저장돼요(가족 휴대폰끼리 공유 안 됨). <em class="add">추가</em> = 길잡이가 더 넣은 항목.</p>'
            + "".join(secs) +
            '<button class="btn" type="button" id="packReset" style="margin-top:14px;width:100%">체크 모두 해제</button></section>')

# ---------- 지금 탭 데이터 ----------
def now_data():
    out = {}
    for d in DAYS:
        seq, items = day_items(d)
        arr = []
        last = None
        for it in items:
            if it["kind"] == "place": last = it["key"]
            if it["kind"] == "place":
                arr.append({"t": it["t"], "s": it["sort"], "k": "place", "a": short(it["key"]), "u": place_url(it["key"]), "n": it["note"],
                            "ik": it["key"] if it["key"] in INFO else "", "dk": f'{d}|p|{it["sort"]}|{it["key"]}',
                            "dest": 1 if it["cat"] in DEST_CATS else 0})
            elif it["kind"] == "move":
                l = it["leg"]
                arr.append({"t": l[4], "s": it["sort"], "k": "move", "a": short(l[1]), "b": short(l[2]), "m": MODE[l[3]],
                            "d": l[5], "tm": l[7], "u": dir_url(l[1], l[2], l[3]), "tr": l[3] == "transit",
                            "tx": l[2] if (l[3] == "driving" and l[2] in TAXI_KEYS) else "", "ik": l[2] if l[2] in INFO else "",
                            "dk": f'{d}|m|{it["sort"]}|{l[1]}>{l[2]}',
                            "uc": f"https://www.google.com/maps/dir/?api=1&destination={quote(P[l[2]][1])}&destination_place_id={P[l[2]][4]}&travelmode={l[3]}"})
            elif it["meal"][2] == PREP_EAT:
                m = it["meal"]
                arr.append({"t": m[1], "s": m[1], "k": "meal", "a": m[2], "n": m[4], "r": [], "rc": 0, "lu": "", "nd": "", "nn": "", "prep": 1, "dk": f'{d}|e|{m[1]}|{m[2]}'})
            else:
                m = it["meal"]
                anc = last or (seq[0] if seq else None)
                recs = meal_recs(d, m, anc)
                arr.append({"t": m[1], "s": m[1], "k": "meal", "a": f"{m[2]} · {AREAS[m[3]].split(' (')[0]}", "n": m[4],
                            "r": [{"n": r[0], "u": rest_url(r), "h": (near_txt(r, anc).split(' (')[0] + ' · ' if anc else '') + r[7]} for r in recs[:4]], "rc": len(recs),
                            "lu": LISTS[AREA_LIST[m[3]]][1] if m[3] in AREA_LIST else "", "nd": near_dir(recs[0]) if recs else "",
                            "nn": recs[0][0].split(" (")[0] if recs else "", "dk": f'{d}|e|{m[1]}|{m[2]}'})
        out[d] = {"date": DAYS[d][0], "title": DAYS[d][2], "items": arr,
                  "crit": [[c[1], c[2], c[3]] for c in CRITICAL if c[0] == d]}
    return out

def jp_chars():
    s = "".join(P[k][1] for k in P) + "".join(r[1] for r in RESTAURANTS) + "".join(t[1] + t[2] + t[3] for t in TAXI)
    s += "この住所までお願いします。ありがとうございます"
    return "".join(sorted(set(ch for ch in s if ord(ch) > 0x2E80)))

def build():
    taxi_sec, taxi_data = taxi_html()
    days = "".join(day_html(d) for d in DAYS)
    chips = "".join(f'<button class="dchip" data-day="{d}" type="button"><b>{d}</b><span>{E(DAYS[d][0])}</span></button>' for d in DAYS)
    jp = quote(jp_chars())
    page = TEMPLATE
    rep = {
        "%%JPTEXT%%": jp, "%%DAYCHIPS%%": chips, "%%DAYS%%": days, "%%FOOD%%": food_html(), "%%TAXI%%": taxi_sec,
        "%%BOOK%%": book_html(), "%%PACK%%": pack_html(),
        "%%INFODATA%%": json.dumps(INFO, ensure_ascii=False).replace("</", "<\\/"), "%%PHOTODATA%%": json.dumps(photos(), ensure_ascii=False), "%%NOWDATA%%": json.dumps(now_data(), ensure_ascii=False).replace("</", "<\\/"),
        "%%TAXIDATA%%": json.dumps(taxi_data, ensure_ascii=False), "%%UPDATED%%": UPDATED,
    }
    for a, b in rep.items():
        page = page.replace(a, b)
    return page

TEMPLATE = r'''<title>후쿠오카 가족여행 길잡이</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@400;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@500;800&display=swap&text=%%JPTEXT%%">
<style>
/* 레이아웃: 휴대폰 한 손 조작 — 위 고정 헤더(날짜 칩) + 가운데 한 줄 타임라인 + 아래 고정 탭 바 */
:root{
  --paper:#eef2f5; --card:#ffffff; --ink:#18212b; --muted:#5a6675; --line:#d9e0e7;
  --sea:#0d6b80; --sea-ink:#ffffff; --sea-soft:#dcedf1;
  --walk:#7a8594; --taxi:#a8670b;
  --alert:#9a4a00; --alert-bg:#fff1dc; --ok:#1d7a46; --est:#8a6d00; --chk:#a33a2b;
  --dest:#c2410c; --dest-ink:#9a3412; --dest-bg:#fff4ec;
  --font:"IBM Plex Sans KR",system-ui,-apple-system,"Apple SD Gothic Neo","Malgun Gothic",sans-serif;
  --mono:"IBM Plex Mono",ui-monospace,"SF Mono",Menlo,monospace;
  --jp:"Noto Sans JP","Hiragino Sans","Yu Gothic",sans-serif;
  --fs:16px;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --paper:#0f151c; --card:#18212b; --ink:#e7edf3; --muted:#9aa7b6; --line:#2a3644;
  --sea:#4fb9d0; --sea-ink:#06232b; --sea-soft:#163541; --walk:#93a0ae; --taxi:#e0a243;
  --alert:#f3b25a; --alert-bg:#33240f; --ok:#5fd394; --est:#e2c35a; --chk:#ff8a7a; --dest:#fb923c; --dest-ink:#fdba74; --dest-bg:#2a1a10; color-scheme:dark}}
:root[data-theme="dark"]{
  --paper:#0f151c; --card:#18212b; --ink:#e7edf3; --muted:#9aa7b6; --line:#2a3644;
  --sea:#4fb9d0; --sea-ink:#06232b; --sea-soft:#163541; --walk:#93a0ae; --taxi:#e0a243;
  --alert:#f3b25a; --alert-bg:#33240f; --ok:#5fd394; --est:#e2c35a; --chk:#ff8a7a; --dest:#fb923c; --dest-ink:#fdba74; --dest-bg:#2a1a10; color-scheme:dark}
*,*::before,*::after{box-sizing:border-box}
[hidden]{display:none!important}
html{font-size:var(--fs)}
body{background:var(--paper);color:var(--ink);font-family:var(--font);font-size:1rem;line-height:1.55;-webkit-text-size-adjust:100%}
body::before{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);z-index:30;background:var(--card)}
a{color:var(--sea)}
.wrap{max-width:560px;margin:0 auto;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:0 calc(88px + env(safe-area-inset-bottom,0px))}
.top{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:var(--card);border-bottom:1px solid var(--line);margin:0 calc(-1 * max(16px,env(safe-area-inset-left,0px))) 0;padding:10px max(16px,env(safe-area-inset-right,0px)) 8px max(16px,env(safe-area-inset-left,0px))}
.toprow{display:flex;align-items:center;gap:8px}
.brand{font-weight:700;font-size:1.02rem;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.brand small{display:block;font-weight:400;color:var(--muted);font-size:.75rem}
.ibtn{border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:10px;min-width:40px;height:40px;font:600 .9rem var(--font)}
.dchips{display:flex;gap:6px;overflow-x:auto;padding-top:8px;scrollbar-width:none}
.dchips::-webkit-scrollbar{display:none}
.dchip{flex:1 0 auto;min-width:52px;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:12px;padding:5px 6px;display:flex;flex-direction:column;align-items:center;font:500 .72rem var(--font);line-height:1.2}
.dchip b{font:600 1rem var(--mono)}
.dchip.on{background:var(--sea);border-color:var(--sea);color:var(--sea-ink)}
.dchip.today{box-shadow:inset 0 -3px 0 var(--alert)}
.tab,.day{padding-top:14px}
.th{font-size:1.25rem;margin:4px 0 12px;text-wrap:balance}
.sub{font-weight:400;color:var(--muted);font-size:.8rem}
.dayhead .dd{font:600 .82rem var(--mono);color:var(--sea);letter-spacing:.02em}
.dayhead h2{font-size:1.3rem;line-height:1.3;margin:2px 0 12px;text-wrap:balance}
.critbox{background:var(--alert-bg);color:var(--ink);border-radius:14px;padding:12px 14px;margin-bottom:12px}
.critbox b{color:var(--alert);font-size:.9rem}
.critbox ul{margin:6px 0 0;padding:0;list-style:none;display:grid;gap:6px}
.ct{font:600 .95rem var(--mono);color:var(--alert);margin-right:4px;font-variant-numeric:tabular-nums}
.miss{display:block;color:var(--muted);font-size:.8rem}
.daymap{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px 12px;margin-bottom:14px}
.daymap summary{font-weight:600;cursor:pointer;list-style-position:outside}
.daymap summary .sub{display:block}
.mapcap{font:600 .78rem var(--font);color:var(--muted);letter-spacing:.06em;margin-bottom:4px}
span.no.rno{background:var(--sea);color:#fff;margin:2px 6px 0 0;flex:0 0 auto;width:auto;display:inline-flex}
ul.recs>li{display:flex!important;gap:6px;align-items:flex-start}
.recs li>div{display:grid;gap:1px;min-width:0}
.rd{font-size:.8rem;color:var(--sea)}
.rt{display:inline-block;margin-left:6px;font:600 .72rem var(--font);color:var(--est);white-space:nowrap}
.rt.mine{color:var(--sea)}
.toast{position:fixed;left:50%;bottom:84px;transform:translateX(-50%);background:rgba(20,24,28,.92);color:#fff;padding:10px 16px;border-radius:20px;font-size:.9rem;z-index:99;opacity:0;pointer-events:none;transition:opacity .2s;max-width:90vw;text-align:center}
.toast.on{opacity:1}
.maplist{margin:8px 0 0;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:4px 12px;font-size:.85rem}
.maplist b{font-family:var(--mono);color:var(--sea);margin-right:2px}
.maplinks{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.fine{color:var(--muted);font-size:.78rem;margin:10px 0 0}
.it.dest .body{border-left:5px solid var(--dest);background:var(--dest-bg)}
.it.dest .no{background:var(--dest);color:#fff}
.it.dest .pname{color:var(--dest-ink)}
.it.dest .cat{border-color:var(--dest);color:var(--dest-ink)}
.body{position:relative}
.dn{position:absolute;top:8px;right:8px;display:inline-flex;align-items:center;gap:4px;border:1px solid var(--line);background:var(--card);color:var(--muted);border-radius:20px;padding:3px 9px 3px 5px;font:600 .72rem var(--font);min-height:30px;cursor:pointer}
.dn-box{width:16px;height:16px;border:2px solid currentColor;border-radius:5px;display:inline-block;position:relative}
.dn[aria-pressed="true"]{background:var(--ok);border-color:var(--ok);color:#fff}
.dn[aria-pressed="true"] .dn-box::after{content:"";position:absolute;left:3px;top:0;width:5px;height:9px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}
.pname,.mhead,.mealh{padding-right:76px}
.it.done .body{opacity:.55}
.it.done .body>:not(.dn):not(.pname):not(.mhead):not(.mdesc):not(.mealh){display:none}
.it.done .tm{text-decoration:line-through;color:var(--muted)}
.it.prep .body{background:var(--alert-bg);border:1px dashed var(--alert)}
.it.prep .mealh{color:var(--alert)}
.alt{margin-top:8px}
.alt summary{cursor:pointer;color:var(--muted);font-size:.82rem}
.altl{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.altl .chip{text-decoration:none}
.fab{position:fixed;right:max(16px,env(safe-area-inset-right,0px));bottom:calc(78px + env(safe-area-inset-bottom,0px));z-index:24;border:0;border-radius:28px;background:var(--alert);color:#fff;font:700 .92rem var(--font);padding:0 18px;min-height:52px;box-shadow:0 4px 14px rgba(0,0,0,.28);display:inline-flex;align-items:center;gap:6px;cursor:pointer}
.fab svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.late{background:var(--alert-bg);color:var(--alert);border-radius:10px;padding:8px 10px;font-weight:700;font-size:.9rem}
.late small{display:block;font-weight:500;color:var(--ink);font-size:.8rem;margin-top:2px}
.nowcard .dn{position:static;align-self:flex-start;min-height:40px;font-size:.85rem;padding:6px 14px 6px 10px}
.shot{position:relative;display:block;margin-top:10px;border-radius:12px;overflow:hidden;border:1px solid var(--line);line-height:0}
.shot img{width:100%;height:auto;display:block}
.bdg{position:absolute;transform:translate(-50%,-50%);background:#18212b;color:#fff;border:2px solid #fff;border-radius:12px;min-width:24px;height:24px;padding:0 5px;display:inline-flex;align-items:center;justify-content:center;font:700 12px/1 var(--mono);box-shadow:0 1px 3px rgba(0,0,0,.35);white-space:nowrap}
.gattr{position:absolute;right:4px;bottom:3px;font:500 9px/1.2 var(--font);color:#333;background:rgba(255,255,255,.8);padding:1px 4px;border-radius:4px}
.daymap .btn.go{margin-top:12px}
.maplinks{align-items:center}
.maplinks .sub{width:100%}
.macts{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 2px}
.macts .btn{background:var(--card)}
.area .btn.walk{margin:0 0 8px}
.info{display:inline-flex;align-items:center;gap:3px;border:1px solid var(--sea);color:var(--sea);background:transparent;border-radius:20px;padding:2px 9px 2px 6px;font:600 .75rem var(--font);min-height:28px;cursor:pointer}
.info svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round}
.infoview{position:fixed;inset:0;z-index:50;background:var(--card);color:var(--ink);overflow:auto;padding:calc(16px + env(safe-area-inset-top,0px)) max(18px,env(safe-area-inset-right,0px)) calc(24px + env(safe-area-inset-bottom,0px)) max(18px,env(safe-area-inset-left,0px))}
.iv-in{max-width:560px;margin:0 auto;display:grid;gap:12px}
.iv-top{display:flex;align-items:flex-start;gap:10px}
.iv-top h2{flex:1;margin:0;font-size:1.3rem;line-height:1.35;text-wrap:balance}
.iv-ph{margin:0;border-radius:14px;overflow:hidden;background:#000}
.iv-ph img{display:block;width:100%;max-height:52vh;object-fit:contain}
.iv-ph figcaption{font-size:.7rem;padding:4px 8px;background:var(--paper)}
.iv-ph figcaption a{color:var(--muted);text-decoration:none}
.iv-one{font-weight:600;color:var(--sea);margin:0}
.iv-desc{margin:0;font-size:1rem;line-height:1.7}
.infoview h3{font-size:.95rem;margin:4px 0 0;color:var(--muted)}
.infoview ul{margin:0;padding-left:1.15rem;display:grid;gap:5px}
.iv-facts{display:grid;gap:6px}
.iv-facts div{display:grid;grid-template-columns:5.5rem 1fr;gap:8px;font-size:.9rem;background:var(--paper);border-radius:10px;padding:8px 10px}
.iv-facts b{color:var(--muted);font-weight:600}
.iv-facts small{display:block;color:var(--muted);font-size:.75rem}
.iv-src{font-size:.8rem;color:var(--muted)}
.iv-src a{overflow-wrap:anywhere}
.pcat h3{font-size:1rem;margin:16px 0 6px}
.plist{list-style:none;margin:0;padding:0;background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden}
.plist li+li{border-top:1px solid var(--line)}
.pk{display:flex;align-items:center;gap:10px;padding:10px 14px;min-height:46px;cursor:pointer}
.pk input{width:22px;height:22px;accent-color:var(--sea);flex:0 0 auto;margin:0}
.pk span{flex:1}
.pk input:checked+span{color:var(--muted);text-decoration:line-through}
em.add{font-style:normal;font-size:.68rem;font-weight:600;color:var(--sea);border:1px solid var(--sea);border-radius:20px;padding:0 6px;flex:0 0 auto}
.cd{font:700 1.05rem var(--font);color:var(--sea)}
.cd.hot{color:var(--chk)}
.critbox li.soon{background:var(--card);border-radius:10px;padding:6px 8px;outline:2px solid var(--chk)}
.soonlab{display:inline-block;font:700 .78rem var(--font);color:#fff;background:var(--chk);border-radius:20px;padding:0 8px;margin-left:4px}
.dest{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.it.next .body{outline:3px solid var(--alert);outline-offset:1px}
.it.flash .body{box-shadow:0 0 0 6px var(--alert-bg)}
.it.next .tm::after{content:"다음";display:block;font:700 .7rem var(--font);color:var(--alert)}
.tl{list-style:none;margin:0;padding:0;display:grid;gap:10px}
.it{display:grid;grid-template-columns:3.2rem 1fr;gap:10px;align-items:start}
.tm{font:600 .95rem var(--mono);padding-top:12px;font-variant-numeric:tabular-nums;color:var(--ink)}
.body{min-width:0;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px}
.place .body{border-left:4px solid var(--ink)}
.pname{font-weight:700;font-size:1.05rem;line-height:1.35;display:flex;flex-wrap:wrap;align-items:center;gap:6px}
.no{font:600 .75rem var(--mono);background:var(--ink);color:var(--card);border-radius:20px;min-width:1.5rem;height:1.5rem;display:inline-flex;align-items:center;justify-content:center;padding:0 5px}
.cat{font-size:.72rem;font-weight:600;color:var(--muted);border:1px solid var(--line);border-radius:20px;padding:1px 8px}
.jp{font-family:var(--jp);color:var(--muted);font-size:.85rem}
.note{margin:6px 0 0;font-size:.9rem;color:var(--ink)}
.acts{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap}
.move .body{background:transparent;border-style:dashed}
.move .tm{color:var(--muted)}
.mhead{display:flex;gap:8px;align-items:center}
.mode{font-weight:700;font-size:.85rem;color:var(--sea)}
.m-walking .mode{color:var(--walk)} .m-driving .mode{color:var(--taxi)}
.st{font-size:.7rem;font-weight:600;border-radius:20px;padding:1px 8px;border:1px solid currentColor}
.st-ok{color:var(--ok)} .st-est{color:var(--est)} .st-chk{color:var(--chk)}
.mdesc{font-weight:600;margin:4px 0 6px}
.kv{display:grid;grid-template-columns:3.6rem 1fr;gap:6px;font-size:.86rem;color:var(--muted)}
.kv span:last-child{color:var(--ink);min-width:0}
.hint{font-size:.8rem;color:var(--muted);background:var(--sea-soft);border-radius:10px;padding:6px 10px;margin-top:8px}
.crit{margin-top:8px;color:var(--alert);font-weight:700;font-size:.88rem}
.btn{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border-radius:12px;font:600 .9rem var(--font);border:1px solid var(--line);color:var(--ink);background:var(--card);padding:8px 12px;min-height:40px;cursor:pointer}
.btn.sm{min-height:34px;padding:4px 10px;font-size:.82rem}
.btn.go{display:flex;width:100%;margin-top:10px;min-height:48px;background:var(--sea);border-color:var(--sea);color:var(--sea-ink);font-size:1rem}
.btn.ghost{background:transparent}
.btn.walk{display:flex;width:100%;margin-top:10px;min-height:44px;color:var(--sea);border-color:var(--sea)}
.meal .body{background:var(--sea-soft);border-color:transparent}
.mealh{font-weight:700}
.meal details summary{cursor:pointer;color:var(--sea);font-weight:600;font-size:.9rem;margin-top:4px}
.recs{list-style:none;margin:8px 0 0;padding:0;display:grid;gap:8px}
.recs li{display:grid;gap:1px}
.rh{font-size:.8rem;color:var(--muted)}
.rm{font-size:.85rem}
.notes{margin-top:14px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px 14px}
.notes summary{font-weight:600;cursor:pointer}
.notes ul{padding-left:1.1rem;margin:8px 0 0;display:grid;gap:6px;font-size:.9rem}
/* 지금 탭 */
.nowcard{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:16px;display:grid;gap:8px}
.nowlab{font:600 .78rem var(--font);color:var(--sea);letter-spacing:.06em}
.nowbig{font-size:1.35rem;font-weight:700;line-height:1.3;text-wrap:balance}
.nowtime{font:600 2rem var(--mono);font-variant-numeric:tabular-nums}
.nowsub{color:var(--muted);font-size:.9rem}
.after{display:grid;gap:6px;margin-top:4px}
.after div{display:grid;grid-template-columns:3.4rem 1fr;font-size:.9rem}
.after span:first-child{font-family:var(--mono);color:var(--muted)}
.sim{margin-top:14px;font-size:.85rem;color:var(--muted);display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.sim select,.sim input{font:500 .9rem var(--font);border:1px solid var(--line);border-radius:10px;padding:6px 8px;background:var(--card);color:var(--ink)}
.quick{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}
.quick .btn{min-height:52px}
/* 식당 */
.chips{display:flex;gap:6px;overflow-x:auto;padding-bottom:6px;scrollbar-width:none}
.chip{flex:0 0 auto;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:20px;padding:6px 12px;font:600 .82rem var(--font)}
.chip.on{background:var(--ink);color:var(--card);border-color:var(--ink)}
.area h3{font-size:1rem;margin:16px 0 8px}
.restlist{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.rest{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;display:grid;gap:2px}
.rn a{font-weight:700;text-decoration:none}
.rs{font-size:.8rem;color:var(--sea);margin-top:4px}
/* 택시 */
.taxilist{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.taxirow{width:100%;text-align:left;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;display:grid;gap:2px;color:var(--ink);font:inherit;cursor:pointer}
.tko{font-weight:700}
.tjp{font-family:var(--jp);font-weight:500;color:var(--muted)}
.taxiview{position:fixed;inset:0;z-index:50;background:var(--card);color:var(--ink);display:flex;flex-direction:column;padding:calc(20px + env(safe-area-inset-top,0px)) max(20px,env(safe-area-inset-right,0px)) calc(20px + env(safe-area-inset-bottom,0px)) max(20px,env(safe-area-inset-left,0px));gap:16px;overflow:auto}
.tv-say{font:500 1.1rem var(--jp)}
.tv-name{font:800 2.4rem/1.25 var(--jp);word-break:keep-all;overflow-wrap:anywhere}
.tv-addr{font:500 1.35rem/1.45 var(--jp)}
.tv-tel{font:600 1.6rem var(--mono)}
.tv-ko{color:var(--muted)}
.tv-close{margin-top:auto;min-height:56px;font-size:1.05rem}
/* 예약 */
.bklist{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.bk{display:grid;grid-template-columns:4.6rem 1fr;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px}
.bd{font:600 .82rem var(--mono);color:var(--sea);padding-top:2px}
.bb{min-width:0}
.bt{font-size:.78rem;color:var(--muted);font-weight:600}
.bm{font-weight:700}
.bx{font-size:.86rem;color:var(--ink);overflow-wrap:anywhere;user-select:text}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin-top:12px}
.card h3{margin:0 0 6px;font-size:1rem}
.plain{margin:0;padding-left:1.1rem;display:grid;gap:4px;font-size:.9rem}
.plain.crits{list-style:none;padding:0}
.mono{font-family:var(--mono);user-select:all}
/* 아래 탭 바 */
.tabbar{position:fixed;left:0;right:0;bottom:0;z-index:25;background:var(--card);border-top:1px solid var(--line);display:grid;grid-template-columns:repeat(6,1fr);padding:6px max(8px,env(safe-area-inset-right,0px)) calc(6px + env(safe-area-inset-bottom,0px)) max(8px,env(safe-area-inset-left,0px))}
.tabbar button{background:none;border:0;color:var(--muted);font:600 .78rem var(--font);display:flex;flex-direction:column;align-items:center;gap:2px;min-height:48px;justify-content:center;border-radius:12px}
.tabbar svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.tabbar button.on{color:var(--sea);background:var(--sea-soft)}
.foot{color:var(--muted);font-size:.75rem;margin-top:24px}
button:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid var(--sea);outline-offset:2px}
@media (prefers-reduced-motion: reduce){*{scroll-behavior:auto!important}}
</style>

<div class="wrap">
  <div class="top">
    <div class="toprow">
      <div class="brand">후쿠오카 가족여행 길잡이<small id="dday">2026.11.23 ~ 11.28 · 5박 6일</small></div>
      <button class="ibtn" id="fsDown" type="button" aria-label="글씨 작게">가-</button>
      <button class="ibtn" id="fsUp" type="button" aria-label="글씨 크게">가+</button>
      <button class="ibtn" id="themeBtn" type="button" aria-label="화면 모드 바꾸기">자동</button>
    </div>
    <div class="dchips" id="dchips">%%DAYCHIPS%%</div>
  </div>

  <section id="now" class="tab">
    <h2 class="th" id="nowTitle">지금 할 일</h2>
    <div id="nowBox"></div>
    <div class="quick">
      <button class="btn" type="button" data-go="taxi">택시 카드</button>
      <button class="btn" type="button" data-go="book">예약·QR</button>
    </div>
    <div class="sim"><label for="simDay">미리보기</label>
      <select id="simDay"><option value="">지금 시각</option></select>
      <input id="simTime" type="time" value="09:00" aria-label="미리보기 시각">
    </div>
  </section>

  %%DAYS%%
  %%FOOD%%
  %%TAXI%%
  %%BOOK%%
  %%PACK%%
  <p class="foot">마지막 수정 %%UPDATED%% · 운행시간·요금은 출발 전에 다시 확인 · 링크를 누르면 구글지도 앱이 열려요</p>
</div>

<div class="taxiview" id="taxiView" hidden role="dialog" aria-modal="true" aria-label="택시 카드">
  <div class="tv-say" lang="ja">この住所までお願いします。</div>
  <div class="tv-name" id="tvName" lang="ja"></div>
  <div class="tv-addr" id="tvAddr" lang="ja"></div>
  <div class="tv-tel" id="tvTel"></div>
  <div class="tv-ko" id="tvKo"></div>
  <button class="btn tv-close" id="tvClose" type="button">닫기</button>
</div>

<div class="infoview" id="infoView" hidden role="dialog" aria-modal="true" aria-labelledby="ivTitle">
  <div class="iv-in">
    <div class="iv-top"><h2 id="ivTitle"></h2><button class="ibtn" id="ivX" type="button" aria-label="닫기">닫기</button></div>
    <div id="ivBody"></div>
    <button class="btn tv-close" id="ivClose" type="button">닫기</button>
  </div>
</div>

<button class="fab" id="fab" type="button" hidden><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>지금 할 일로</button>

<nav class="tabbar" aria-label="메뉴">
  <button type="button" data-tab="now"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>지금</button>
  <button type="button" data-tab="day"><svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="15" rx="2.5"/><path d="M4 9.5h16M9 3v4M15 3v4"/></svg>일정</button>
  <button type="button" data-tab="food"><svg viewBox="0 0 24 24"><path d="M7 3v8a2 2 0 0 0 4 0V3M9 11v10M16 3c-2 1.5-2.5 4-2.5 7H17V21"/></svg>식당</button>
  <button type="button" data-tab="taxi"><svg viewBox="0 0 24 24"><path d="M5 16V11l2-5h10l2 5v5M3.5 16h17M7.5 19.5v-3M16.5 19.5v-3M10 6V4h4v2"/><circle cx="8" cy="13" r=".8"/><circle cx="16" cy="13" r=".8"/></svg>택시</button>
  <button type="button" data-tab="book"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><path d="M14 14h2v2h-2zM18 18h2v2h-2zM14 18h2"/></svg>예약</button>
  <button type="button" data-tab="pack"><svg viewBox="0 0 24 24"><rect x="5" y="4" width="14" height="17" rx="2.5"/><path d="M9 4V3h6v1M8.5 10l1.8 1.8L14 8M8.5 16h7"/></svg>준비물</button>
</nav>

<script>
(function(){
  var NOW = %%NOWDATA%%;
  var TAXI = %%TAXIDATA%%;
  var INFO = %%INFODATA%%;
  var PHOTO = %%PHOTODATA%%;
  var START = Date.UTC(2026,10,23); // 11/23 (일본 날짜 기준)
  function store(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v);}catch(e){return null}}
  var root=document.documentElement;
  // 글씨 크기
  var fs=parseFloat(store('fs'))||16;
  function setFs(v){fs=Math.max(14,Math.min(22,v));root.style.setProperty('--fs',fs+'px');store('fs',String(fs));}
  setFs(fs);
  document.getElementById('fsUp').onclick=function(){setFs(fs+1)};
  document.getElementById('fsDown').onclick=function(){setFs(fs-1)};
  // 화면 모드: 시스템 → 밝게 → 어둡게
  var themes=['','light','dark'], ti=Math.max(0,themes.indexOf(store('theme')||''));
  function setTheme(i){ti=i;if(themes[i])root.setAttribute('data-theme',themes[i]);else root.removeAttribute('data-theme');store('theme',themes[i]);
    document.getElementById('themeBtn').textContent=['자동','밝게','어둡게'][i];}
  setTheme(ti);
  document.getElementById('themeBtn').onclick=function(){setTheme((ti+1)%3)};

  // 일본 시각
  function jst(){var n=new Date(Date.now()+9*3600e3);return {day:Math.floor((Date.UTC(n.getUTCFullYear(),n.getUTCMonth(),n.getUTCDate())-START)/864e5)+1,min:n.getUTCHours()*60+n.getUTCMinutes(),hm:('0'+n.getUTCHours()).slice(-2)+':'+('0'+n.getUTCMinutes()).slice(-2)}}
  function mm(t){var p=t.split(':');return +p[0]*60+ +p[1]}

  // 탭
  var days=[].slice.call(document.querySelectorAll('section.day'));
  var tabs=['now','food','taxi','book','pack'];
  var curDay=1;
  // 뒤로가기: 화면 이동·소개창·택시 카드를 기록에 쌓고, 첫 화면에서는 두 번 눌러야 닫힘
  function hpush(st,h){try{history.pushState(st,'','#'+h)}catch(e){}}
  function hrep(st,h){try{history.replaceState(st,'','#'+h)}catch(e){}}
  function curHash(){return (location.hash||'#now').slice(1)}
  function toast(msg){var t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';t.className='toast';document.body.appendChild(t);}
    t.textContent=msg;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(function(){t.classList.remove('on')},2000);}
  function show(tab,day,nopush){
    tabs.forEach(function(t){document.getElementById(t).hidden=(t!==tab)});
    days.forEach(function(s){s.hidden=!(tab==='day'&&+s.dataset.day===day)});
    if(tab==='day'){curDay=day;store('day',String(day));}
    [].forEach.call(document.querySelectorAll('.dchip'),function(c){c.classList.toggle('on',tab==='day'&&+c.dataset.day===day)});
    [].forEach.call(document.querySelectorAll('.tabbar button'),function(b){b.classList.toggle('on',b.dataset.tab===tab)});
    var h=tab==='day'?'day-'+day:tab; if(location.hash!=='#'+h){if(nopush)hrep({v:h},h);else hpush({v:h},h);}
    fab.hidden=(tab!=='day');
    if(tab==='day'){var j=jst();markNext(day,(sd.value&&+sd.value===day)?mm(st.value||'09:00'):(j.day===day?j.min:0));}
    window.scrollTo(0,0);
  }
  function route(){
    var h=(location.hash||'').slice(1);
    var m=/^day-(\d)$/.exec(h);
    if(m)show('day',+m[1],true); else if(tabs.indexOf(h)>=0)show(h,curDay,true); else show('now',curDay,true);
  }
  [].forEach.call(document.querySelectorAll('.tabbar button'),function(b){b.onclick=function(){show(b.dataset.tab,curDay)}});
  [].forEach.call(document.querySelectorAll('.dchip'),function(c){c.onclick=function(){show('day',+c.dataset.day)}});
  [].forEach.call(document.querySelectorAll('[data-go]'),function(b){b.onclick=function(){show(b.dataset.go,curDay)}});

  // 택시 카드
  var tv=document.getElementById('taxiView');
  function openTaxi(k){var t=TAXI[k];if(!t)return;document.getElementById('tvName').textContent=t.jp;document.getElementById('tvAddr').textContent=t.addr;
    document.getElementById('tvTel').textContent=t.tel?('☎ '+t.tel):'';document.getElementById('tvKo').textContent=t.ko;if(tv.hidden)hpush({ov:'taxi'},curHash());tv.hidden=false;
    try{navigator.wakeLock&&navigator.wakeLock.request('screen').catch(function(){})}catch(e){}}
  document.addEventListener('click',function(e){var b=e.target.closest('[data-taxi]');if(b)openTaxi(b.dataset.taxi)});
  function closeTaxi(fromPop){if(tv.hidden)return;tv.hidden=true;if(!fromPop&&history.state&&history.state.ov)history.back();}
  document.getElementById('tvClose').onclick=function(){closeTaxi()};

  // 식당 지역 필터
  [].forEach.call(document.querySelectorAll('.chip'),function(c){c.onclick=function(){
    [].forEach.call(document.querySelectorAll('.chip'),function(x){x.classList.toggle('on',x===c)});
    [].forEach.call(document.querySelectorAll('.area'),function(a){a.hidden=!(c.dataset.area==='all'||a.dataset.area===c.dataset.area)});
  }});

  // 관광지 소개
  var iv=document.getElementById('infoView'), ivLast=null;
  function openInfo(k){var d=INFO[k];if(!d)return;ivLast=document.activeElement;
    document.getElementById('ivTitle').textContent=d.title;
    var ph=PHOTO[k];
    var h=(ph?'<figure class="iv-ph"><img src="'+ph.src+'" alt="'+esc(d.title)+' 사진"><figcaption><a href="'+esc(ph.url)+'" target="_blank" rel="noopener">'+esc(ph.cap)+'</a></figcaption></figure>':'')+'<p class="iv-one">'+esc(d.oneline)+'</p><p class="iv-desc">'+esc(d.desc)+'</p>';
    if(d.highlights&&d.highlights.length)h+='<h3>볼거리·할 거리</h3><ul>'+d.highlights.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ul>';
    if(d.tips&&d.tips.length)h+='<h3>알아두면 좋은 점</h3><ul>'+d.tips.map(function(x){return '<li>'+esc(x)+'</li>'}).join('')+'</ul>';
    if(d.facts&&d.facts.length)h+='<h3>운영 정보 <span class="sub">2026-10-30 조사 · 바뀔 수 있어요</span></h3><div class="iv-facts">'+d.facts.map(function(f){
      return '<div><b>'+esc(f.label)+'</b><span>'+esc(f.value)+(f.source?'<small>출처: '+esc(f.source)+'</small>':'')+'</span></div>'}).join('')+'</div>';
    if(d.sources&&d.sources.length)h+='<div class="iv-src">자료: '+d.sources.map(function(x){return '<a href="'+esc(x.url)+'" target="_blank" rel="noopener">'+esc(x.title)+'</a>'}).join(' · ')+'</div>';
    h+='<p class="fine">(추정)이라고 쓴 부분은 확인 못 한 내용이에요.</p>';
    document.getElementById('ivBody').innerHTML=h;if(iv.hidden)hpush({ov:'info'},curHash());iv.hidden=false;iv.scrollTop=0;document.getElementById('ivX').focus();}
  function closeInfo(fromPop){if(iv.hidden)return;iv.hidden=true;if(ivLast&&ivLast.focus)try{ivLast.focus()}catch(e){}
    if(fromPop!==true&&history.state&&history.state.ov)history.back();}
  document.addEventListener('click',function(e){var b=e.target.closest('[data-info]');if(b){e.preventDefault();openInfo(b.dataset.info)}});
  document.getElementById('ivX').onclick=function(){closeInfo()};document.getElementById('ivClose').onclick=function(){closeInfo()};
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){if(!iv.hidden)closeInfo();if(!tv.hidden)closeTaxi();}});

  // 준비물
  var PK={};try{PK=JSON.parse(store('pack')||'{}')||{}}catch(e){PK={}}
  var boxes=[].slice.call(document.querySelectorAll('[data-pk]'));
  function packCount(){var t=0,c=0;
    [].forEach.call(document.querySelectorAll('.pcat'),function(p){var bs=p.querySelectorAll('[data-pk]'),k=0;
      [].forEach.call(bs,function(b){if(b.checked)k++});t+=bs.length;c+=k;p.querySelector('.pcnt').textContent=k+'/'+bs.length});
    document.getElementById('packCnt').textContent=c+' / '+t+' 챙김';}
  boxes.forEach(function(b){b.checked=!!PK[b.dataset.pk];b.onchange=function(){if(b.checked)PK[b.dataset.pk]=1;else delete PK[b.dataset.pk];
    store('pack',JSON.stringify(PK));packCount();}});
  packCount();
  var pr=document.getElementById('packReset'),prT=null;
  pr.onclick=function(){if(!prT){pr.textContent='한 번 더 누르면 모두 해제';prT=setTimeout(function(){prT=null;pr.textContent='체크 모두 해제'},3000);return;}
    clearTimeout(prT);prT=null;PK={};store('pack','{}');boxes.forEach(function(b){b.checked=false});packCount();pr.textContent='체크 모두 해제';};

  function left(d){if(d<=0)return '지금';var h=Math.floor(d/60),m=d%60;return h?(h+'시간'+(m?' '+m+'분':'')):m+'분'}
  // 완료 표시 (휴대폰마다 저장)
  var DONE={};try{DONE=JSON.parse(store('done')||'{}')||{}}catch(e){DONE={}}
  function applyDone(){[].forEach.call(document.querySelectorAll('.tl>.it[data-k]'),function(li){var on=!!DONE[li.dataset.k];li.classList.toggle('done',on);
    var b=li.querySelector('.dn');if(b){b.setAttribute('aria-pressed',on?'true':'false');b.querySelector('.dn-t').textContent=on?'완료됨':'완료';}});}
  function toggleDone(k){if(DONE[k])delete DONE[k];else DONE[k]=1;store('done',JSON.stringify(DONE));applyDone();renderNow();}
  document.addEventListener('click',function(e){var b=e.target.closest('[data-done]');if(b){e.preventDefault();toggleDone(b.dataset.done);}});
  // 다음 항목: 그날 완료 표시가 있으면 '마지막 완료 다음', 없으면 시각 기준
  function nextIdx(list,keyOf,timeOf,isMove,min){var last=-1,i;
    for(i=0;i<list.length;i++)if(DONE[keyOf(list[i])])last=i;
    if(last>=0){for(i=last+1;i<list.length;i++){if(!DONE[keyOf(list[i])]&&(timeOf(list[i])||isMove(list[i])))return {i:i,by:'done'};}return {i:null,by:'done'};}
    for(i=0;i<list.length;i++){var it=list[i];if(mm(it._s)>=min&&(timeOf(it)||isMove(it)))return {i:i,by:'time'};}
    return {i:null,by:'time'};}
  function markNext(day,min){[].forEach.call(document.querySelectorAll('.it.next'),function(x){x.classList.remove('next')});
    var sec=document.getElementById('day-'+day);if(!sec)return;var its=[].slice.call(sec.querySelectorAll('.tl>.it'));
    its.forEach(function(li){li._s=li.dataset.t});
    var r=nextIdx(its,function(li){return li.dataset.k},function(li){return li.querySelector('.tm').textContent.trim()},function(li){return li.classList.contains('move')},min);
    if(r.i!==null)its[r.i].classList.add('next');}
  var fab=document.getElementById('fab');
  fab.onclick=function(){var sec=document.getElementById('day-'+curDay);if(!sec)return;
    var t=sec.querySelector('.it.next')||[].slice.call(sec.querySelectorAll('.tl>.it')).filter(function(li){return !li.classList.contains('done')})[0];
    if(t){var y=t.getBoundingClientRect().top+window.scrollY-170;window.scrollTo({top:Math.max(0,y),behavior:'smooth'});t.classList.add('flash');setTimeout(function(){t.classList.remove('flash')},1200);}};
  function ibtn(k){return k&&INFO[k]?'<button class="info" type="button" data-info="'+esc(k)+'"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>소개</button>':''}

  // 지금 할 일
  var sd=document.getElementById('simDay'), st=document.getElementById('simTime');
  Object.keys(NOW).forEach(function(d){var o=document.createElement('option');o.value=d;o.textContent=d+'일차 '+NOW[d].date;sd.appendChild(o)});
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function renderNow(){
    var j=jst(), day=j.day, min=j.min, sim=!!sd.value;
    if(sim){day=+sd.value;min=mm(st.value||'09:00');}
    markNext(0,0);
    var box=document.getElementById('nowBox'), title=document.getElementById('nowTitle');
    [].forEach.call(document.querySelectorAll('.dchip'),function(c){c.classList.toggle('today',!sim&&+c.dataset.day===j.day)});
    if(day<1){var dd=1-day;title.textContent='여행까지 '+dd+'일';
      document.getElementById('dday').textContent='D-'+dd+' · 2026.11.23 ~ 11.28';
      box.innerHTML='<div class="nowcard"><div class="nowlab">출발 날 첫 일정</div><div class="nowbig">05:30 인천공항 T1 발렛 → 08:10 에어서울 (T2)</div>'+
        '<div class="nowsub">여행 중에는 이 화면이 그 시각의 다음 할 일과 길찾기 버튼을 보여줘요. 아래 미리보기로 날짜·시각을 골라 확인해 볼 수 있어요.</div>'+
        '<button class="btn go" type="button" id="toDay1">1일차 일정 보기</button></div>';
      document.getElementById('toDay1').onclick=function(){show('day',1)};return;}
    if(day>6){title.textContent='여행 끝';box.innerHTML='<div class="nowcard"><div class="nowbig">수고했어요. 다음 여행에서 만나요.</div></div>';return;}
    markNext(day,min);
    var D=NOW[day], items=D.items, next=null, i;
    items.forEach(function(x){x._s=x.s});
    var nr=nextIdx(items,function(x){return x.dk},function(x){return x.t},function(x){return x.k==='move'},min);next=nr.i;
    title.textContent=(sim?'미리보기 · ':'오늘 · ')+day+'일차 '+D.date;
    if(next===null){var lastP=items.filter(function(x){return x.k==='place'}).pop();
      box.innerHTML='<div class="nowcard"><div class="nowlab">오늘 일정 끝</div><div class="nowbig">'+(day===6?'19:55 제주항공 · 수속·보안검색 후 탑승 대기':esc(lastP.a)+'에서 쉬기')+'</div>'+
      (day<6?'<button class="btn go" type="button" id="toDayN">내일 일정 보기</button>':'')+'</div>';
      if(day<6)document.getElementById('toDayN').onclick=function(){show('day',day+1)};return;}
    var it=items[next], h='', cur=null;
    if(nr.by==='done'){for(i=next-1;i>=0;i--){if(DONE[items[i].dk]){cur=items[i];break;}}
      if(cur)h+='<div class="nowsub">방금 완료: '+esc(cur.k==='move'?(cur.a+' → '+cur.b):cur.a)+'</div>';}
    else{var bt=-1;for(i=next-1;i>=0;i--){var x=items[i];if(x.t&&mm(x.t)<=min&&mm(x.t)>bt){bt=mm(x.t);cur=x;}}
      if(cur)h+='<div class="nowsub">'+(cur.k==='move'?'이동 중: '+esc(cur.t)+' '+esc(cur.a)+' → '+esc(cur.b):'지금: '+esc(cur.t)+' '+esc(cur.a))+'</div>';}
    var dl=mm(it.t||it.s)-min;
    if(it.t&&dl<-5)h+='<div class="late">예정보다 '+left(-dl)+' 늦어요<small>열차·배·택시처럼 시각이 정해진 것(위 빨간 목록)을 먼저 지키고, 관광지는 줄이거나 [완료]로 건너뛰세요.</small></div>';
    if(it.k==='move'){
      h+='<div class="nowlab">다음 이동 · '+esc(it.m)+'</div><div class="nowtime">'+esc(it.t||'바로')+'</div>'+
        (it.t?'<div class="cd'+(dl<=10?' hot':'')+'">'+(dl<=0?'지금 출발할 시간':'출발까지 '+left(dl)+' 남음')+'</div>':'')+
        '<div class="dest"><span class="nowbig">→ '+esc(it.b)+'</span>'+ibtn(it.ik)+'</div><div class="nowsub">출발: '+esc(it.a)+' · '+esc(it.d)+' · '+esc(it.tm)+'</div>'+
        (it.tr&&it.t?'<div class="hint">구글지도에서 <b>출발 시간 → '+esc(it.t)+'</b>으로 바꾸기</div>':'')+
        '<a class="btn go" href="'+esc(it.uc)+'" target="_blank" rel="noopener">길찾기 열기 (지금 내 위치에서)</a>'+
        (it.tx?'<button class="btn" type="button" data-taxi="'+esc(it.tx)+'">택시 카드 · '+esc(it.b)+'</button>':'');
    }else if(it.prep){
      h+='<div class="nowlab">다음 할 일</div><div class="nowtime">'+esc(it.t)+'</div><div class="nowbig">'+esc(it.a)+'</div><div class="nowsub">'+esc(it.n)+'</div>';
    }else if(it.k==='meal'){
      h+='<div class="nowlab">다음 식사</div><div class="nowtime">'+esc(it.t)+'</div><div class="cd">'+(dl<=0?'지금':left(dl)+' 뒤')+'</div><div class="nowbig">'+esc(it.a)+'</div>'+
        (it.n?'<div class="nowsub">'+esc(it.n)+'</div>':'')+
        (it.r.length?'<ul class="recs">'+it.r.map(function(r){return '<li><a href="'+esc(r.u)+'" target="_blank" rel="noopener"><b>'+esc(r.n)+'</b></a><span class="rh">'+esc(r.h)+'</span></li>'}).join('')+'</ul>'+
          (it.rc>it.r.length?'<div class="nowsub">외 '+(it.rc-it.r.length)+'곳은 일정 화면에서</div>':'')+
          '<div class="macts">'+(it.lu?'<a class="btn" href="'+esc(it.lu)+'" target="_blank" rel="noopener">전체 식당 지도</a>':'')+
          (it.nd?'<a class="btn" href="'+esc(it.nd)+'" target="_blank" rel="noopener">가장 가까운 곳 길찾기 · '+esc(it.nn)+'</a>':'')+'</div>'
          :'<div class="nowsub">저장한 식당 중 맞는 곳 없음</div>');
    }else{
      h+='<div class="nowlab">다음 목적지</div><div class="nowtime">'+esc(it.t)+'</div><div class="cd">'+(dl<=0?'지금':left(dl)+' 뒤')+'</div>'+
        '<div class="dest"><span class="nowbig">'+esc(it.a)+'</span>'+ibtn(it.ik)+'</div>'+
        (it.n?'<div class="nowsub">'+esc(it.n)+'</div>':'')+'<a class="btn go" href="'+esc(it.u)+'" target="_blank" rel="noopener">지도에서 보기</a>';
    }
    h+='<button class="dn" type="button" data-done="'+esc(it.dk)+'" aria-pressed="false"><span class="dn-box"></span><span class="dn-t">이거 끝났어요 (완료)</span></button>';
    var after=items.slice(next+1).filter(function(x){return x.t}).slice(0,4).map(function(x){
      return '<div><span>'+esc(x.t)+'</span><span>'+esc(x.k==='move'?(x.a+' → '+x.b):x.a)+'</span></div>'}).join('');
    var crit=D.crit.filter(function(c){return mm(c[0])>=min}).map(function(c){var d=mm(c[0])-min,soon=d<=30;
      return '<li'+(soon?' class="soon"':'')+'><span class="ct">'+esc(c[0])+'</span> '+esc(c[1])+(soon?'<span class="soonlab">'+(d<=0?'지금':d+'분 남음')+'</span>'+(c[2]?'<span class="miss">놓치면: '+esc(c[2])+'</span>':''):'')+'</li>'}).join('');
    box.innerHTML=(crit?'<div class="critbox"><b>앞으로 놓치면 안 되는 시각</b><ul>'+crit+'</ul></div>':'')+
      '<div class="nowcard">'+h+(after?'<div class="nowlab" style="margin-top:6px">그다음</div><div class="after">'+after+'</div>':'')+
      '<button class="btn" type="button" id="toDayCur">'+day+'일차 전체 보기</button></div>';
    document.getElementById('toDayCur').onclick=function(){show('day',day)};
  }
  sd.onchange=renderNow; st.onchange=renderNow; st.oninput=renderNow;
  var j0=jst(); curDay=(j0.day>=1&&j0.day<=6)?j0.day:(+store('day')||1);
  applyDone(); renderNow(); setInterval(function(){if(!sd.value)renderNow()},30000);
  route();
  // 첫 화면 아래에 '닫기 대기' 기록을 하나 깔아 둔다 → 첫 화면에서 뒤로가기 1번은 안내만, 2초 안에 한 번 더 누르면 닫힘
  var lastRoot=0;
  (function(){var h=curHash();hrep({root:1},h);hpush({v:h},h);})();
  window.addEventListener('popstate',function(e){
    var st=e.state||{};
    if(!iv.hidden){closeInfo(true);if(!st.ov&&!st.root)return;}
    if(!tv.hidden){closeTaxi(true);if(!st.ov&&!st.root)return;}
    if(st.root){var t=Date.now();
      if(t-lastRoot<2000){history.back();return;}
      lastRoot=t;toast('뒤로가기를 한 번 더 누르면 길잡이가 닫혀요');hpush({v:curHash()},curHash());return;}
    if(st.ov){history.back();return;}
    route();
  });
})();
</script>
'''

if __name__ == "__main__":
    out = build()
    if APP:
        for a_, b_ in [(" (JR 65011)", ""), (" (JR 69616)", ""), ("예약 65011, ", ""), ("예약 69616, ", ""),
                       ("<li>유후인노모리 65011 · 소닉 69616</li>", "<li>승차권 QR 링크는 비공개 모음(메일)에</li>")]:
            out = out.replace(a_, b_)
        head = ('<link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0d6b8c">'
                '<link rel="apple-touch-icon" href="icon-192.png"><meta name="apple-mobile-web-app-capable" content="yes">'
                '<meta name="robots" content="noindex,nofollow">')
        out = ('<!doctype html>\n<html lang="ko"><head><meta charset="utf-8">'
               '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">' + head + '</head><body>\n'
               + out + "<script>if('serviceWorker' in navigator){navigator.serviceWorker.register('sw.js').catch(function(){})}</script>\n</body></html>\n")
        _os.makedirs("app", exist_ok=True)
        open("app/index.html", "w", encoding="utf-8").write(out)
    else:
        open("guide.html", "w", encoding="utf-8").write(out)
    print(len(out))
