# -*- coding: utf-8 -*-
# 구글 '내 지도'(My Maps) 가져오기용 KML — 날짜별 폴더(레이어), 같은 장소도 순서대로 중복, 하루 동선 선
import html
from data import P, DAYS, day_chain, place_url
import make_html as M
E = html.escape
COL = ["ff8c6b0d", "ff0b67a8", "ff2b3aa3", "ff467a1d", "ff7a3d8a", "ff00668c"]  # aabbggrr
def build():
    out = ['<?xml version="1.0" encoding="UTF-8"?>', '<kml xmlns="http://www.opengis.net/kml/2.2"><Document>',
           '<name>후쿠오카 가족여행 2026 동선</name>']
    for d in DAYS:
        out.append(f'<Style id="l{d}"><LineStyle><color>{COL[d-1]}</color><width>4</width></LineStyle></Style>')
    for d in DAYS:
        seq, items = M.day_items(d)
        date, dow, title = DAYS[d]
        out.append(f'<Folder><name>{d}일차 {date}({dow[0]}) {E(title)}</name>')
        places = [it for it in items if it["kind"] == "place"]
        for it in places:
            k = it["key"]; ko, jp, lat, lng, pid = P[k]
            t = it["t"] or ""
            name = f'{d}-{it["no"]:02d} {t} {ko.split(" (")[0]}'.replace("  ", " ")
            desc = f'{E(jp)}<br>{E(it["note"])}<br><a href="{E(place_url(k))}">구글지도</a>'
            out.append(f'<Placemark><name>{E(name)}</name><description><![CDATA[{desc}]]></description>'
                       f'<Point><coordinates>{lng},{lat},0</coordinates></Point></Placemark>')
        coords = " ".join(f'{P[k][3]},{P[k][2]},0' for k in seq)
        out.append(f'<Placemark><name>{d}일차 동선</name><styleUrl>#l{d}</styleUrl><LineString><tessellate>1</tessellate>'
                   f'<coordinates>{coords}</coordinates></LineString></Placemark></Folder>')
    out.append('</Document></kml>')
    return "\n".join(out)
if __name__ == "__main__":
    s = build(); open("fukuoka_route_2026.kml", "w", encoding="utf-8").write(s)
    print(len(s), s.count("<Placemark>"))
